public class ExampleMain {
	
public static void main(String[] args) {
	int arg = args.length;
	System.out.println("Hi from Java!");
	System.out.println("there are " + args.length + " arguments");
if (arg == 0) {
	  System.out.println("You didn't provide any arguments.");
	}

int argumentNumbers;
for (argumentNumbers = 0; argumentNumbers < args.length; ++argumentNumbers)
{
	System.out.print("Argument: ");
	System.out.println(args[argumentNumbers]);
}
}
}