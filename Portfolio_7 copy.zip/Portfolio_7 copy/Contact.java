class Contact {
  private String firstName;
  private String surname;
  private String emailAddy;
  private String phoneNumber;
  
  public Contact(String fn, String sn, String ea, String pn){
    firstName = fn;
    surname = sn;
    emailAddy = ea;
    phoneNumber = pn;
  }
  
  public String toString(){
    return (firstName+" "+ surname+"\n"+emailAddy+"\n"+phoneNumber);
  }
}
  
  
  
