class Style {
  int colourFill;
  int strokeColor;
  int backgroundColor;
  int textSize;
  String name;
 
  public Style(String label, int backgroundCol, int stroke, int fill, int textSizeInt) {
    colourFill = fill;
    strokeColor = stroke;
    backgroundColor = backgroundCol;
    textSize= textSizeInt;
    name = label;
  }

  public String getName() {
    return name;
  }

  public int getFillColor() {
    return colourFill;
  }

  public int getStrokeColor() {
    return strokeColor;
  }
  public int getTextSize() {
    return textSize;
  }
  public int getBackground() {
    return backgroundColor;
  }
}
