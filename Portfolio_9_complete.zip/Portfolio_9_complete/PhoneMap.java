import java.util.HashMap;
import java.util.ArrayList;
class PhoneMap{
  HashMap<String, Phone> phones = new HashMap<String, Phone>();

  public PhoneMap(){
    phones = new HashMap<String, Phone>();
  }
  public void addPhone(Phone newPhone){
    String ab = newPhone.getBrand()+newPhone.getModel();
    phones.put(ab, newPhone);
  }

  public ArrayList getCostOver(int price){
    ArrayList<Phone> phonesCost = new ArrayList<Phone>(); {
      for (String opq : phones.keySet()){
        Phone item = phones.get(opq);
        if (item.getApprox_price_EUR()>price){
          phonesCost.add(item);
          System.out.println(item);
        }
      }
      return phonesCost;
    }
  }
  public void printPhoneMap(){
    for (String lmn : phones.keySet()){
      Phone item =  phones.get(lmn);
      System.out.println(item);
    }
  }
 
    public int getSize(){
    return phones.size();
  }
}
