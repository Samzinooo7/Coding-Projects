public class adder2 {
adder2() { }
	public static int add(int num1, int num2) {
		
		return num1+num2;
	}
}

