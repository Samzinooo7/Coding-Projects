public class adder {

	public static void main(String[] args) {
		if ((args.length !=2)) {
			System.out.println("Please privde two integer parameters");
		} else {
			int num0 = Integer.parseInt(args[0]);
			int num1 = Integer.parseInt(args[1]);
			adder2 a = new adder2();
			int result = adder2.add(num1,num0);
			System.out.println("The result of adding "+ args[0] +"and "+ args[1] " is");
			
			
		}
	}
}
