import java.util.ArrayList;
import java.util.Collections;
class PhoneList{
  ArrayList<Phone> phones;

  public PhoneList(){
    phones = new ArrayList<Phone>();
  }

  public void addPhone(Phone anotherPhone){
    phones.add(anotherPhone);
  }
  public int getSize(){
    return phones.size();
  }

  public void printPhoneList(){
    for (Phone PL : phones){
      System.out.println(PL);
    }
  }
  public void sort(){
    Collections.sort(phones);
  }

  public PhoneList findPhone(String manufacturer, String modelname){
    PhoneList findPhone;
    findPhone = new PhoneList();
    for (Phone PP: phones){
      if (PP.getBrand().equals(manufacturer) && PP.getModel().equals(modelname)){
        findPhone.addPhone(PP);
        System.out.println(PP);
      }
    }
    return findPhone;
  }

  public PhoneList getCost(int priceTag){
    PhoneList Cost;
    Cost = new PhoneList();
    for (Phone priceTotal : phones){
      if (priceTotal.getApprox_price_EUR() > priceTag){
        Cost.addPhone(priceTotal);
        System.out.println(priceTotal);
      }
    }
    return Cost;
  }
}
